@echo off
rem UULA Restyle - install without the exe (if Windows blocks it)
set "D=%LOCALAPPDATA%\UULA Restyle"
mkdir "%D%" 2>nul
copy /Y "%~dp0UULA-Restyle.xml" "%D%\UULA-Restyle.xml" >nul
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\Developer" /v "UULA Restyle" /t REG_SZ /d "%D%\UULA-Restyle.xml" /f >nul
echo.
echo UULA Restyle is installed. Close PowerPoint and Word and open them again.
echo.
pause
