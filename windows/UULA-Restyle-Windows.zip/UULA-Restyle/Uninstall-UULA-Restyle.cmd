@echo off
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\Developer" /v "UULA Restyle" /f >nul 2>&1
rmdir /S /Q "%LOCALAPPDATA%\UULA Restyle" 2>nul
echo UULA Restyle was removed. Restart PowerPoint and Word.
pause
