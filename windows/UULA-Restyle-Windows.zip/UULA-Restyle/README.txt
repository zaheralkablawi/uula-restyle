﻿أداة UULA Restyle لبرنامج PowerPoint (ويندوز)
================================================

التثبيت:
1) فك ضغط هذا الملف (Extract All).
2) شغّل الملف UULA-Restyle-Setup.exe (دبل كلك).
   إذا ظهرت رسالة Windows protected your PC: اضغط More info ثم Run anyway.
3) أغلق PowerPoint تمامًا ثم افتحه من جديد.
4) زر UULA Restyle يظهر في تبويب Home.
   إذا لم يظهر: Insert ← Add-ins ← My Add-ins ← Developer Add-ins.

إذا منع الويندوز ملف exe: شغّل Install-UULA-Restyle.cmd بدلًا منه.

التحديثات تصل تلقائيًا، لا حاجة لإعادة التثبيت.
للإزالة: شغّل الـ exe مرة ثانية واختر "لا"، أو شغّل Uninstall-UULA-Restyle.cmd.

المتطلبات:
- Microsoft 365 (PowerPoint) محدّث.
- خط UULA Sans مثبّت على الجهاز.
- اتصال بالإنترنت.

------------------------------------------------
UULA Restyle for PowerPoint (Windows)
1) Extract the zip.  2) Run UULA-Restyle-Setup.exe (if SmartScreen appears: More info > Run anyway).
3) Restart PowerPoint. The button is on the Home tab (or Insert > Add-ins > My Add-ins > Developer Add-ins).
If the exe is blocked, run Install-UULA-Restyle.cmd. Updates are automatic.
Needs an up-to-date Microsoft 365, the UULA Sans font and internet access.

By Zaher Alkablawi
