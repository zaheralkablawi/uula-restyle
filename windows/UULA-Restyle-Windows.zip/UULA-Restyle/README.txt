﻿أداة UULA Restyle لبرنامجي PowerPoint وWord (ويندوز)
=====================================================

التثبيت:
1) فك ضغط هذا الملف (Extract All).
2) شغّل الملف UULA-Restyle-Setup.exe (دبل كلك).
   إذا ظهرت رسالة Windows protected your PC: اضغط More info ثم Run anyway.
3) أغلق PowerPoint وWord تمامًا ثم افتحهما من جديد.
4) زر UULA Restyle يظهر في تبويب Home في البرنامجين.
   في الوورد: تمييز أجزاء المذكرة. في الباوربوينت: التحويل، ومن «إدراج» ← إدراج ملف وورد.
   إذا لم يظهر: Insert ← Add-ins ← My Add-ins ← Developer Add-ins.

إذا منع الويندوز ملف exe: شغّل Install-UULA-Restyle.cmd بدلًا منه.

التحديثات تصل تلقائيًا، لا حاجة لإعادة التثبيت.
للإزالة: شغّل الـ exe مرة ثانية واختر "لا"، أو شغّل Uninstall-UULA-Restyle.cmd.

المتطلبات:
- Microsoft 365 (PowerPoint وWord) محدّث.
- خط UULA Sans مثبّت على الجهاز.
- اتصال بالإنترنت.

------------------------------------------------
UULA Restyle for PowerPoint and Word (Windows)
1) Extract the zip.  2) Run UULA-Restyle-Setup.exe (if SmartScreen appears: More info > Run anyway).
3) Restart PowerPoint and Word. The button is on the Home tab (or Insert > Add-ins > My Add-ins > Developer Add-ins).
If the exe is blocked, run Install-UULA-Restyle.cmd. Updates are automatic.
Needs an up-to-date Microsoft 365, the UULA Sans font and internet access.

By Zaher Alkablawi
